package com.example.coinbit

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.URL
import java.text.NumberFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    // Definir uma variável global para armazenar a cotação do Bitcoin
    var cotacaoBitcoin: Double = 0.0
    private val API_URL = "https://www.mercadobitcoin.net/api/BTC/ticker/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val btnCalcular = findViewById<Button>(R.id.btnCalcular)
        val txtCotacao = findViewById<TextView>(R.id.txtCotacao)

        // Iniciar a busca pela cotação do Bitcoin
        buscarCotacao(txtCotacao)

        // Configurar o botão de cálculo
        btnCalcular.setOnClickListener {
            calcular()
        }
    }

    // Função para buscar a cotação do Bitcoin
    private fun buscarCotacao(txtCotacao: TextView) {
        // Usar uma Coroutine para buscar a cotação do Bitcoin em segundo plano
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Fazer a requisição para a API e pegar a resposta
                val response = URL(API_URL).readText()

                // Parse da resposta JSON para pegar o valor da cotação
                cotacaoBitcoin = JSONObject(response).getJSONObject("ticker").getDouble("last")

                // Formatando a cotação para exibição
                val f = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
                val cotacaoFormatada = f.format(cotacaoBitcoin)

                // Atualizar o TextView com a cotação formatada
                withContext(Dispatchers.Main) {
                    txtCotacao.text = "Cotação: $cotacaoFormatada"
                }
            } catch (e: Exception) {
                // Caso ocorra algum erro na requisição ou parsing
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    txtCotacao.text = "Erro ao buscar cotação"
                }
            }
        }
    }

    // Função para calcular a quantidade de Bitcoin
    private fun calcular() {
        val txtValor = findViewById<EditText>(R.id.txtValor)
        val txtQtdBitcoin = findViewById<TextView>(R.id.txtQtdBitcoin)

        // Verificar se o campo de valor foi preenchido
        if (txtValor.text.isEmpty()) {
            txtValor.error = "Preencha um valor"
            return
        }

        try {
            // Converter o valor digitado para Double (com tratamento de vírgula como ponto)
            val valorDigitado = txtValor.text.toString()
                .replace(",", ".") // Substituir vírgula por ponto
                .toDouble()
            // Verificar se a cotação do Bitcoin é maior que 0
            if (cotacaoBitcoin > 0) {
                // Calcular a quantidade de Bitcoin
                val resultado = valorDigitado / cotacaoBitcoin

                // Exibir o resultado formatado
                txtQtdBitcoin.text = String.format("%.8f", resultado) // Exibir 8 casas decimais
            } else {
                // Caso a cotação seja 0 ou inválida
                txtQtdBitcoin.text = "Erro na cotação"
            }
        } catch (e: NumberFormatException) {
            // Caso ocorra erro na conversão do valor digitado
            txtValor.error = "Valor inválido"
        }
    }
}
