package com.example.aposentadoriaalterada

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    companion object {
        const val IDADE_M = 65
        const val IDADE_F = 62
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val spinSexo = findViewById<Spinner>(R.id.spinSexo)
        val txtIdade = findViewById<EditText>(R.id.txtIdade)
        val btnCalcular = findViewById<Button>(R.id.btn_Calcular)
        val txtResultado = findViewById<TextView>(R.id.txt_Resultado)

        spinSexo.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("Masculino", "Feminino")
        )

        btnCalcular.setOnClickListener {
            val sexo = spinSexo.selectedItem as String
            val idadeInput = txtIdade.text.toString()
            var resultado = 0

            if (idadeInput.isEmpty()) {
                txtResultado.text = "A idade não pode estar vazia."
                return@setOnClickListener
            }

            val idade = idadeInput.toIntOrNull()
            if (idade == null || idade < 0) {
                txtResultado.text = "Por favor, insira uma idade válida."
                return@setOnClickListener
            }

            resultado = if (sexo == "Masculino") {
                IDADE_M - idade
            } else {
                IDADE_F - idade
            }
            txtResultado.text = if (resultado > 0) {
                "Faltam $resultado anos para você se aposentar!"
            } else {
                "Você já pode se aposentar!"
            }
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}
