package com.example.calculoaposentadoria

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        val spinSexo = findViewById<Spinner>(R.id.spinSexo)
        val txtIdade = findViewById<EditText>(R.id.txtIdade)
        val btnCalcular = findViewById<Button>(R.id.btn_Calcular)
        val txtResultado = findViewById<TextView>(R.id.txt_Resultado)


        spinSexo.adapter = ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, listOf("Masculino", "Feminio"))

        btnCalcular.setOnClickListener {
            val sexo = spinSexo.selectedItem as String
            val idade = txtIdade.text.toString().toInt()
            var resultado = 0
            if(sexo == "Masculino"){
                resultado = 65 - idade
            }else{
                resultado = 60 - idade

            }
            //saida
            txtResultado.text = "Faltam $resultado anos para voce se aposentar!"

        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}