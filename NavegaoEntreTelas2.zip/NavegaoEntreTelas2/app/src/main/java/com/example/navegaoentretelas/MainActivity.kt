package com.example.navegaoentretelas
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editTextEmail: EditText
    private lateinit var editTextSenha: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextEmail = findViewById(R.id.editText)
        editTextSenha = findViewById(R.id.editText2)
    }

    // Método para o botão "VOLTAR"
    fun GotoMain(view: View) {
        // Fecha a Activity atual, voltando à anterior
        finish()
    }

    // Método para o botão "ENTRAR"
    fun sendMessage(view: View) {
        val email = editTextEmail.text.toString()
        val senha = editTextSenha.text.toString()

        if (email.isEmpty() || senha.isEmpty()) {
            // Notifica o usuário que os campos são obrigatórios
            Toast.makeText(this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show()
        } else {
            // Lógica para autenticação
            if (email == "usuario@exemplo.com" && senha == "1234") {
                // Ação em caso de sucesso, redirecionando para uma nova Activity, por exemplo
                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent) // Substitua por sua Activity de destino
                Toast.makeText(this, "Login bem-sucedido!", Toast.LENGTH_SHORT).show()
            } else {
                // Ação em caso de erro na autenticação
                Toast.makeText(this, "E-mail ou senha incorretos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Método para "Esqueci minha senha"
    fun forgotPassword(view: View) {
        // Lógica para recuperação de senha
        // Exemplo: Exibir uma mensagem para o usuário
        Toast.makeText(this, "Função de recuperação de senha em desenvolvimento", Toast.LENGTH_SHORT).show()

        // Outra opção é redirecionar para uma nova Activity que implementará a recuperação de senha
        // val intent = Intent(this, RecuperarSenhaActivity::class.java)
        // startActivity(intent)
    }
}
